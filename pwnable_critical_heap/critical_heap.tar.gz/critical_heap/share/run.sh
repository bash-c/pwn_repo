#!/bin/bash
#
exec 2>/dev/null
timeout 60 /home/critical_heap++/critical_heap
