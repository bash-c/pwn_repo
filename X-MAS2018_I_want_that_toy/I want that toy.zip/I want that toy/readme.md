Santa created a submission system that allows you to request toys for this Christmas. Give it a try!

Server: http://199.247.6.180:10000/

Libc: libc.so.6

Author: littlewho

本地运行：启动server，通过浏览器访问http://localhost:1337