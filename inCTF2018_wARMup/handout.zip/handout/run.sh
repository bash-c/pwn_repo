#!/bin/bash
unset LD_LIBRARY_PATH
qemu-arm -L ./ ./wARMup

